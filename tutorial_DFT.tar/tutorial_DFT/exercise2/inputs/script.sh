#!/bin/bash -l
#
#SBATCH --job-name=DFTtute # Job name
#SBATCH --partition=cpu # Partition
#SBATCH --nodes=1 # Number of nodes
#SBATCH --ntasks-per-node=40 # Number of cores
#SBATCH --output=job.out # Stdout (%j=jobId)
#SBATCH --error=job.err # Stderr (%j=jobId)
#SBATCH -A p263 # Tutorial code
# Load any necessary modules
module load intel/2023a
module load imkl/2023.1.0
module load impi/2021.9.0-intel-compilers-2023.1.0
QE=/nvme/h/mzacharias/scratch/q-e/bin # path to QE executables
cd $PWD
mpirun -np 40 $QE/pw.x -nk 4 < si.PBE0.in > si.PBE0.out

exit
mpirun -np 40 $QE/pw.x -nk 20 < si.scf.in > si.scf.out
mpirun -np 40 $QE/pw.x -nk 20 < si.bands.in > si.bands.out
mpirun -np 40 $QE/bands.x -nk 20 < bands.in > bands.out
mpirun -np 40 $QE/pw.x -nk 4 < si.HSE.in > si.HSE.out
