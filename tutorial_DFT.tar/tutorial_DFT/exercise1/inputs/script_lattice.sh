#!/bin/bash -l
# 
#SBATCH --job-name=DFTtute # Job name
#SBATCH --partition=cpu # Partition
#SBATCH --nodes=1 # Number of nodes
#SBATCH --ntasks-per-node=40 # Number of cores
#SBATCH --output=job.out # Stdout (%j=jobId)
#SBATCH --error=job.err # Stderr (%j=jobId)
#SBATCH -A p263 # Tutorial code

# Load any necessary modules
module load intel/2023a
module load imkl/2023.1.0
module load impi/2021.9.0-intel-compilers-2023.1.0
QE=/nvme/h/mzacharias/scratch/q-e/bin # path to compiled QE
cd $PWD

array=("9.90" "9.95" "10.00" "10.05" "10.10" "10.15" "10.20" "10.25" "10.30" "10.35" "10.40" "10.45" "10.50")
for j in ${array[@]}; do
#
  cp si.scf_lattice.in si.scf_"$j"_Bohr.in
  sed -i 's/AAA/'$j'/g' si.scf_"$j"_Bohr.in
  mpirun -np 4 $QE/pw.x < si.scf_"$j"_Bohr.in > si.scf_"$j"_Bohr.out
done
