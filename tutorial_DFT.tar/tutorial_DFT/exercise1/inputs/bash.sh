#!/bin/bash
j=10
f=50
while [ $j -le $f ];do
#
  cp si.scf_Ry.in si.scf_"$j"Ry.in
  sed -i 's/AAA/'$j'/g' si.scf_"$j"Ry.in
  $QE/pw.x < si.scf_"$j"Ry.in > si.scf_"$j"Ry.out
  j=$((j+5))
done

