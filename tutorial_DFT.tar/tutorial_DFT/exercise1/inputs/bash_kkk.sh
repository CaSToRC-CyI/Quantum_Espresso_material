#!/bin/bash
j=3
f=14
while [ $j -le $f ];do
#
  cp si.scf_kkk.in si.scf_k"$j""$j""$j".in
  sed -i 's/KKK/'$j'/g' si.scf_k"$j""$j""$j".in
  $QE/pw.x < si.scf_k"$j""$j""$j".in > si.scf_k"$j""$j""$j".out
  j=$((j+1))
done

