#!/bin/bash -l
# 
#SBATCH --job-name=DFTtute # Job name
#SBATCH --partition=cpu # Partition
#SBATCH --nodes=1 # Number of nodes
#SBATCH --ntasks-per-node=40 # Number of cores
#SBATCH --output=job.out # Stdout (%j=jobId)
#SBATCH --error=job.err # Stderr (%j=jobId)
#SBATCH -A p263 # Tutorial code

# Load any necessary modules
module load intel/2023a
module load imkl/2023.1.0
module load impi/2021.9.0-intel-compilers-2023.1.0
QE=/nvme/h/mzacharias/scratch/q-e/bin # path to compiled QE
cd $PWD

#!/bin/bash
j=3
f=14
while [ $j -le $f ];do
#
  cp si.scf_kkk.in si.scf_k"$j""$j""$j".in
  sed -i 's/KKK/'$j'/g' si.scf_k"$j""$j""$j".in
  mpirun -np 4  $QE/pw.x < si.scf_k"$j""$j""$j".in > si.scf_k"$j""$j""$j".out
  j=$((j+1))
done
